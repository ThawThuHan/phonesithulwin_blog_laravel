<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/unicode.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>

    <?php
        $orders = App\Models\Order::all();
    ?>

    <div class="row g-0">
        <div class="col-2" style="background-color: darkslateblue;">
            <div class="sticky-top d-flex flex-column justify-content-between" style="height: 100vh;">
                <div>
                    <h3 class="py-2 px-3 d-none d-md-block text-white text-center">Admin Panel</h3>
                    <ul class="list-group px-1 px-md-3 pt-5 pt-md-0">
                        <a href="<?php echo e(route("admin_panel")); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-list"></i>
                            <span class="d-none d-md-inline">Categories</span>
                        </a>
                        <a href="<?php echo e(route("admin_panel.articles")); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-pen-square"></i>
                            <span class="d-none d-md-inline">Articles</span>
                        </a>
                        <a href="<?php echo e(route("admin_panel.books")); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-book-medical"></i>
                            <span class="d-none d-md-inline">Books</span>
                        </a>
                        <a href="<?php echo e(route("admin_panel.orders")); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-cart-plus"></i>
                            <span class="d-none d-md-inline">Orders</span>
                            <span class="badge rounded-pill bg-danger float-end"><?php echo e(count($orders)); ?></span>
                        </a>
                        <a href="admin_panel_users.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-users"></i>
                            <span class="d-none d-md-inline">Users</span>
                        </a>
                    </ul>
                </div>
                <ul class="list-group px-1 px-md-3 py-3">
                    <a href="<?php echo e(route('logout')); ?>" class="list-group-item list-group-item-action" 
                    onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();
                    ">
                        <i class="fa fa-sign-out-alt"></i>
                        <span class="d-none d-md-inline">Logout</span>
                    </a>
                    <form id='logout-form' action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <?php echo $__env->yieldContent("script"); ?>
</body>
</html><?php /**PATH E:\php-web-projects\phonestl_blog\resources\views\layouts\admin_panel_master.blade.php ENDPATH**/ ?>