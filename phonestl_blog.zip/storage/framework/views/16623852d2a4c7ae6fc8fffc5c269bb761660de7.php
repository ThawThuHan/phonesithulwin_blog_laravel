

<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h2 class="text-center mb-4 sub-title"><?= $category->name ?></h2>
    <div class="row px-3">
        <?php foreach ($posts as $post) : ?>
            <?php
            $content = str_replace("\"", "\\\"", $post->content);
            $content = strip_tags($content);
            ?>
            <div onclick="location.href='/posts/<?php echo e($post->id); ?>'" class="col-12 col-md-6 col-lg-4 mb-3">
                <div class="card blogShadow">
                    <img src="<?php echo e(URL("storage/post_images/".$post->image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body border-bottom">
                        <h5 class="card-title d-inline"><?php echo e($post->title); ?></h5>
                        <div class="text-muted">
                            <span><?php echo e($post->created_at); ?></span>
                            <span class="card-subtitle float-end"><i class="fas fa-eye"></i> <?php echo e($post->view_count); ?></span>
                        </div>
                        <p class="card-text mt-4">
                            <?php echo e(mb_strimwidth($content, 0, 100, '...', 'utf-8')); ?>

                        </p>
                        <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-info mt-2 float-end text-white">Read more</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php-web-projects\phonestl_blog\resources\views\posts.blade.php ENDPATH**/ ?>