

<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .sub-title {
            color: white;
            text-shadow: 2px 2px 4px #000000;
        }

        .error {
            height: 300px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4 sub-title">Search Result: <?php echo e($search); ?> </h2>
        <?php if(count($posts) > 0): ?>
            <div class="row mb-0 mb-md-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $content = str_replace("\"", "\\\"", $post->content);
                $content = strip_tags($content);
                ?>
                <div class="col-12 col-md-6 col-lg-4 mb-3">
                    <a href="/posts/<?php echo e($post->id); ?>" class="text-decoration-none text-dark blog">
                        <div class="card blogShadow">
                            <img src="<?php echo e(URL("storage/post_images/".$post->image)); ?>" class="card-img-top" alt="...">
                            <div class="card-body border-bottom">
                                <h5 class="card-title d-inline"><?php echo e($post->title); ?></h5>
                                <div class="text-muted">
                                    <span><?php echo e($post->created_at); ?></span>
                                    <span class="card-subtitle float-end"><i class="fas fa-eye"></i> <?php echo e($post->view_count); ?></span>
                                </div>
                                <p class="card-text mt-4">
                                    <?php echo e(mb_strimwidth($content, 0, 100, '...', 'utf-8')); ?>

                                </p>
                                <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-info mt-2 float-end text-white">Read more</a>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="error d-flex align-items-center justify-content-center">
                <h1>No Result Found!</h1>
            </div>
        <?php endif; ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php-web-projects\phonestl_blog\resources\views\search.blade.php ENDPATH**/ ?>