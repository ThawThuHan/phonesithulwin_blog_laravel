

<?php $__env->startSection('title', $current->title); ?>

<?php $__env->startSection('content'); ?>
<div class="row mx-2">
    <div class="col-sm-12 col-md-8">
        <div class="mb-4" style="width: 100%; height: 350px;">
            <img src="<?php echo e(asset('storage/post_images/'.$current->image)); ?>" alt="" style="width: 100%; height: 100%; object-fit: contain;">
        </div>
        <h2 class=""><?php echo e($current->title); ?></h2>
        <span><?php echo e($current->created_at); ?></span>
        <small>-by <b>Dr.Phone Sithu Lwin</b></small>
        <p>
            <?= $current->content ?>
        </p>

        <!-- share -->
        <h6 class="mx-5 border-top d-inline">Share this:</h6>
        <?php
        $url = rawurlencode("http://localhost/phonesithulwin_blog/blog.php");
        ?>
        <div class="mx-5 mt-1 d-flex align-items-center gap-1" id="footer">
            <!-- facebook -->
            <a href="http://www.facebook.com/sharer.php?u=<?php echo e(Request::url()); ?>" class="fab fa-facebook fs-4 text-primary mx-1 my-2 text-decoration-none"></a>
            <!-- telegram -->
            <a href="https://t.me/share?url=<?php echo e(Request::url()); ?>" class="fab fa-telegram fs-4 mx-1 my-2 text-decoration-none"></a>
            <!-- twitter -->
            <a href="https://twitter.com/intent/tweet?original_referer=<?php echo e(Request::url()); ?>" class="fab fa-twitter fs-4 text-primary mx-1 my-2 text-decoration-none"></a>
            <!-- linkedin -->
            <a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(Request::url()); ?>" class="fab fa-linkedin fs-4"></a>
            <!-- <a href="#" class="fab fa-pinterest fs-4 text-danger mx-1 my-2 text-decoration-none"></a> -->
        </div>
    </div>
    <div class="col-md-4 col-xs-12">
        <!-- popular posts -->
        <h3 class="">Popular Posts</h3>
        <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/posts/<?php echo e($post->id); ?>">
            <div class="row my-2">
                <div class="col-3">
                    <div class="" style="width: 100%; height: 65px;">
                        <img src="<?php echo e(asset('storage/post_images/'.$post->image)); ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                </div>
                <div class="col-9 d-flex align-items-center">
                    <p>
                        <b><?php echo e($post->title); ?></b>
                    </p>
                </div>
            </div>
        </a>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- recent posts -->
        <h3 class="mt-4">Recent Posts</h3>
        <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/posts/<?php echo e($post->id); ?>">
            <div class="row my-2">
                <div class="col-3">
                    <div class="" style="width: 100%; height: 65px;">
                        <img src="<?php echo e(asset('storage/post_images/'.$post->image)); ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                </div>
                <div class="col-9 d-flex align-items-center">
                    <p>
                        <b><?php echo e($post->title); ?></b>
                    </p>
                </div>
            </div>
        </a>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- share -->
<!-- <h6 class="mx-5 border-top d-inline">Share this:</h6>
<div class="mx-5 mt-1 d-flex align-items-center gap-1" id="footer">
    <a href="#" class="fab fa-facebook fs-4 text-primary mx-1 my-2 text-decoration-none"></a>
    <a href="#" class="fab fa-telegram fs-4 mx-1 my-2 text-decoration-none"></a>
    <a href="#" class="fab fa-youtube fs-4 text-danger mx-1 my-2 text-decoration-none"></a>
    <a href="#" class="fab fa-twitter fs-4 text-primary mx-1 my-2 text-decoration-none"></a>
    <a href="#" class="fab fa-pinterest fs-4 text-danger mx-1 my-2 text-decoration-none"></a>
</div>
<hr><hr> -->
<!-- related posts -->
<h2 class="mx-2 mt-5">Related Posts</h2>
<div class="row mx-2 mt-3">
    <div class="row g-0 g-md-3">
        <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xs-12 col-md-4 col-sm-6 mb-3">
            <a href="/posts/<?php echo e($post->id); ?>" class="text-decoration-none text-dark blog">
                <div class="card blogShadow">
                    <img src="<?php echo e(asset("storage/post_images/".$post->image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body border-bottom">
                        <h3 class="card-title d-inline"><?php echo e($post->title); ?></h3>
                        <span class="float-end">1.2k<i class="fas fa-eye"></i></span>
                        <br>
                        <br>
                        <p class="card-text">
                            <?php echo e(mb_strimwidth($post->content, 0, 100, '...', 'utf-8')); ?>

                        </p>
                        <span><?php echo e($post->created_at); ?></span>
                        <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-info float-end text-white">Read more</a>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>

    

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php-web-projects\phonestl_blog\resources\views\post.blade.php ENDPATH**/ ?>