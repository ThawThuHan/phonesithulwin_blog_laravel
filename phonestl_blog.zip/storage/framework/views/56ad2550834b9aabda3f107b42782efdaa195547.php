<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Order Confirm</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['message']); ?></p>
</body>
</html><?php /**PATH E:\php-web-projects\phonestl_blog\resources\views\emails\confirm.blade.php ENDPATH**/ ?>